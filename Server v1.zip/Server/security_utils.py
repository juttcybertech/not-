def apply_security_headers(app):
    """
    Applies security headers to all responses to prevent XSS and other attacks.
    Usage: In your main Flask app file, import this function and call apply_security_headers(app)
    """
    @app.after_request
    def add_header(response):
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'SAMEORIGIN'
        response.headers['X-XSS-Protection'] = '1; mode=block'
        response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
        return response