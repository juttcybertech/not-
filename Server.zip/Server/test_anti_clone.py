import requests

TARGET = "http://127.0.0.1:8080"
SECRET = "jutt_tiktok_shield_2026_x92z_secure_key"

def test_api_security():
    print("--- Testing API Security (Anti-Clone) ---")
    
    # 1. Test WITHOUT secret
    print("\nTesting request WITHOUT secret...")
    try:
        res = requests.post(f"{TARGET}/api/preview", json={"url": "test"})
        print(f"Status: {res.status_code}")
        if res.status_code == 403:
            print("[SUCCESS] Access Denied as expected!")
        else:
            print("[FAILURE] Server allowed access or returned unexpected code.")
    except Exception as e:
        print(f"Error: {e}")

    # 2. Test WITH WRONG secret
    print("\nTesting request WITH WRONG secret...")
    try:
        res = requests.post(f"{TARGET}/api/preview", 
                            json={"url": "test"},
                            headers={"X-API-Secret": "wrong_key"})
        print(f"Status: {res.status_code}")
        if res.status_code == 403:
            print("[SUCCESS] Access Denied as expected!")
        else:
            print("[FAILURE] Server allowed access or returned unexpected code.")
    except Exception as e:
        print(f"Error: {e}")

    # 3. Test WITH CORRECT secret
    print("\nTesting request WITH CORRECT secret...")
    try:
        # Note: We expect a 400 (Invalid TikTok URL) if the secret check passes
        res = requests.post(f"{TARGET}/api/preview", 
                            json={"url": "invalid_url"},
                            headers={"X-API-Secret": SECRET})
        print(f"Status: {res.status_code}")
        if res.status_code == 400:
            print("[SUCCESS] Secret accepted! (Server proceeded to URL validation)")
        elif res.status_code == 200:
             print("[SUCCESS] Secret accepted!")
        else:
            print(f"[FAILURE] Unexpected status code: {res.status_code}")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    test_api_security()
