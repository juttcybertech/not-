from waitress import serve
from app import app
import os

if __name__ == "__main__":
    # Get port from environment or default to 8080 (standard for production)
    # You can change this to 80 or 443 if you have admin rights and want standard web ports
    port = int(os.environ.get("PORT", 8080))
    
    print(f"Starting PRODUCTION Server on http://0.0.0.0:{port}")
    print(f"Admin Configured at: {os.environ.get('ADMIN_ACCESS_PATH', '/admin')}")
    print("-------")
    
    # Run with EXTREME concurrency (300 parallel connections)
    # Note: Video downloading is CPU/Network intensive.
    serve(app, host="0.0.0.0", port=8080, threads=32)
