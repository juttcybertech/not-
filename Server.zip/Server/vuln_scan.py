import requests

TARGET = "http://127.0.0.1:8080"

def test_xss():
    print(f"\n--- Testing XSS (Cross-Site Scripting) ---")
    payload = "<script>alert('XSS')</script>"
    # Try injecting into the preview endpoint which reflects data
    try:
        # The /api/preview endpoint returns JSON, so standard reflection XSS is unlikely unless
        # the frontend mishandles it (which we checked).
        # But let's see if the server sanitizes inputs before processing.
        res = requests.post(f"{TARGET}/api/preview", json={"url": payload})
        if payload in res.text:
            print("[VULNERABLE] Reflection found in response body!")
        else:
            print("[SAFE] Payload not reflected or blocked.")
            print(f"Server response: {res.status_code}")
    except Exception as e:
        print(f"Error: {e}")

def test_admin_sqli():
    print(f"\n--- Testing SQL Injection on Admin Login ---")
    # Simple payload
    payload = "' OR '1'='1"
    try:
        res = requests.post(f"{TARGET}/admin", data={"username": payload, "password": "password"})
        if "Logs" in res.text or "Dashboard" in res.text:
             print("[VULNERABLE] SQL Injection successful! Admin panel accessed.")
        else:
             print("[SAFE] SQL Injection failed.")
    except Exception as e:
        print(f"Error: {e}")

def test_debug_info():
    print(f"\n--- Testing Information Leakage ---")
    # Try to trigger an error
    try:
        # Sending malformed JSON to trigger 400/500
        res = requests.post(f"{TARGET}/api/preview", data="malformed json")
        if "Traceback" in res.text or "Werkzeug" in res.text:
             print("[VULNERABLE] Stack trace exposed!")
        else:
             print("[SAFE] Error handled gracefully.")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    test_xss()
    test_admin_sqli()
    test_debug_info()
