import os, time, uuid, json, requests, subprocess, zipfile, logging, concurrent.futures, random
from threading import Thread
from yt_dlp import YoutubeDL, DownloadError
from functools import lru_cache

# ✅ Global session for connection pooling
session = requests.Session()
session.headers.update({'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'})

# Setup basic logging for the model
logger = logging.getLogger(__name__)

# Constants
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'downloads')

# User-Agent rotation pool to avoid detection/blocking
USER_AGENTS = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15',
]

def get_random_user_agent():
    """Returns a random User-Agent from the pool."""
    return random.choice(USER_AGENTS)

# Request throttling for photo downloads to avoid rate limiting
_last_photo_request_time = {}
_photo_request_lock = __import__('threading').Lock()

def throttle_photo_request(url, min_delay=2.0):
    """Throttle photo requests to avoid triggering rate limits.
    
    Args:
        url: The URL being requested
        min_delay: Minimum delay in seconds between requests (default: 2s)
    """
    with _photo_request_lock:
        current_time = time.time()
        # Use a simple hash of the URL to track per-URL throttling
        url_key = hash(url) % 1000
        
        if url_key in _last_photo_request_time:
            elapsed = current_time - _last_photo_request_time[url_key]
            if elapsed < min_delay:
                sleep_time = min_delay - elapsed
                logger.info(f"Throttling photo request, sleeping for {sleep_time:.2f}s")
                time.sleep(sleep_time)
        
        _last_photo_request_time[url_key] = time.time()
        
        # Clean up old entries (keep only last 100)
        if len(_last_photo_request_time) > 100:
            oldest_keys = sorted(_last_photo_request_time.keys(), 
                               key=lambda k: _last_photo_request_time[k])[:50]
            for k in oldest_keys:
                del _last_photo_request_time[k]

def run_gallery_dl_with_retry(cmd, max_retries=3, timeout=30):
    """Run gallery-dl command with retry logic and exponential backoff.
    
    Args:
        cmd: Command list to execute
        max_retries: Maximum number of retry attempts
        timeout: Timeout in seconds for each attempt
    
    Returns:
        subprocess.CompletedProcess object
    
    Raises:
        Exception: If all retries fail
    """
    for attempt in range(max_retries):
        try:
            # Add random User-Agent to environment
            env = os.environ.copy()
            env['HTTP_USER_AGENT'] = get_random_user_agent()
            
            logger.info(f"gallery-dl attempt {attempt + 1}/{max_retries}: {' '.join(cmd)}")
            
            result = subprocess.run(
                cmd, 
                capture_output=True, 
                text=True, 
                check=True, 
                timeout=timeout,
                env=env
            )
            
            logger.info(f"gallery-dl succeeded on attempt {attempt + 1}")
            return result
            
        except subprocess.TimeoutExpired as e:
            logger.warning(f"gallery-dl timeout on attempt {attempt + 1}/{max_retries}: {e}")
            if attempt == max_retries - 1:
                raise Exception(f"gallery-dl timed out after {max_retries} attempts")
                
        except subprocess.CalledProcessError as e:
            error_msg = e.stderr if e.stderr else str(e)
            logger.warning(f"gallery-dl failed on attempt {attempt + 1}/{max_retries}: {error_msg}")
            
            # Check for specific error patterns
            if 'Unsupported URL' in error_msg or 'No results' in error_msg:
                logger.error(f"gallery-dl does not support this URL format: {error_msg}")
                raise Exception(f"Unsupported URL format for gallery-dl: {error_msg}")
            
            if attempt == max_retries - 1:
                raise Exception(f"gallery-dl failed after {max_retries} attempts: {error_msg}")
        
        except Exception as e:
            logger.error(f"Unexpected error on attempt {attempt + 1}/{max_retries}: {e}")
            if attempt == max_retries - 1:
                raise
        
        # Exponential backoff: 2^attempt seconds (2s, 4s, 8s)
        if attempt < max_retries - 1:
            backoff_time = 2 ** attempt
            logger.info(f"Waiting {backoff_time}s before retry...")
            time.sleep(backoff_time)
    
    raise Exception("gallery-dl failed: max retries exceeded")

def schedule_deletion(file_path, delay=300):
    def delete_file():
        time.sleep(delay)
        if os.path.exists(file_path):
            try:
                os.remove(file_path)
                logger.debug(f"Deleted temporary file: {file_path}")
            except Exception as e:
                logger.error(f"Error deleting file {file_path}: {e}")
    Thread(target=delete_file, daemon=True).start()

def start_cleanup_service():
    """Starts a background thread that cleans up the downloads folder every 5 minutes."""
    def periodic_cleanup():
        while True:
            try:
                now = time.time()
                for f in os.listdir(UPLOAD_FOLDER):
                    file_path = os.path.join(UPLOAD_FOLDER, f)
                    # Delete files older than 5 minutes (300 seconds)
                    if os.path.isfile(file_path) and (now - os.path.getmtime(file_path) > 300):
                        try:
                            os.remove(file_path)
                            # Safe logging for filenames with special characters
                            safe_f = f.encode('ascii', 'backslashreplace').decode('ascii')
                            logger.info(f"Cleanup: Removed old file {safe_f}")
                        except: pass
                    # Also clean up empty directories if any (from failed image downloads)
                    elif os.path.isdir(file_path) and (now - os.path.getmtime(file_path) > 300):
                        try:
                            import shutil
                            shutil.rmtree(file_path, ignore_errors=True)
                            safe_f = f.encode('ascii', 'backslashreplace').decode('ascii')
                            logger.info(f"Cleanup: Removed old directory {safe_f}")
                        except: pass
            except Exception as e:
                logger.error(f"Error in periodic cleanup: {e}")
            time.sleep(300) # Run every 5 minutes
            
    Thread(target=periodic_cleanup, daemon=True).start()
    logger.info("Background cleanup service started (5-minute cycle).")

@lru_cache(maxsize=128)
def resolve_tiktok_url(url):
    if not url: return url
    if 'vt.tiktok.com' in url or 'vm.tiktok.com' in url:
        try:
            resp = session.head(url, allow_redirects=True, timeout=5)
            return resp.url
        except Exception as e:
            logger.error(f"Error resolving URL {url}: {e}")
            return url
    return url

def download_tiktok_video(url):
    unique_id = str(uuid.uuid4())[:8]
    # Optimized opts: no-playlist, no-warnings, prefer mp4 to avoid merging if possible
    ydl_opts = { 
        'format': 'bestvideo[height<=720][ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best', 
        'outtmpl': os.path.join(UPLOAD_FOLDER, f'%(title)s_{unique_id}.%(ext)s'), 
        'quiet': True,
        'no_warnings': True,
        'noplaylist': True,
        'nocheckcertificate': True
    }
    with YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=True)
        file_path = ydl.prepare_filename(info)
        schedule_deletion(file_path)
        return file_path

def download_audio(url):
    unique_id = str(uuid.uuid4())[:8]
    ydl_opts = { 
        'format': 'bestaudio/best', 
        'outtmpl': os.path.join(UPLOAD_FOLDER, f'%(title)s_{unique_id}.%(ext)s'), 
        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'mp3',
            'preferredquality': '192',
        }], 
        'quiet': True 
    }
    try:
        with YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)
            base_path = os.path.splitext(ydl.prepare_filename(info))[0]
            final_path = base_path + '.mp3'
            if os.path.exists(final_path):
                schedule_deletion(final_path)
                return final_path
            raise DownloadError("Audio conversion failed.")
    except DownloadError as e:
        if '/photo/' in url:
             try:
                cmd = ["python", "-m", "gallery_dl", "--dump-json", url]
                res = run_gallery_dl_with_retry(cmd, max_retries=3, timeout=30)
                data = json.loads(res.stdout) if res.stdout.strip().startswith('{') or res.stdout.strip().startswith('[') else [json.loads(l) for l in res.stdout.strip().split('\n') if l.strip()]
                
                audio_url = None
                def find_music(d):
                    if isinstance(d, dict):
                        if 'music' in d and 'playUrl' in d['music']: return d['music']['playUrl']
                        for v in d.values():
                            found = find_music(v)
                            if found: return found
                    if isinstance(d, list):
                        for item in d:
                            found = find_music(item)
                            if found: return found
                    return None
                audio_url = find_music(data)
                if audio_url:
                    unique_id = str(uuid.uuid4())[:8]
                    temp_path = os.path.join(UPLOAD_FOLDER, f"audio_{unique_id}.mp3")
                    r = requests.get(audio_url, stream=True)
                    if r.status_code == 200:
                        with open(temp_path, 'wb') as f:
                            for chunk in r.iter_content(chunk_size=8192): f.write(chunk)
                        schedule_deletion(temp_path)
                        return temp_path
             except Exception as ex: logger.error(f"Fallback audio failed: {ex}")
        raise e

def download_tiktok_images(url):
    unique_id = str(uuid.uuid4())[:8]
    output_dir = os.path.join(UPLOAD_FOLDER, f'images_{unique_id}')
    os.makedirs(output_dir, exist_ok=True)
    try:
        if '/photo/' in url:
            run_gallery_dl_with_retry(["python", "-m", "gallery_dl", "--directory", output_dir, url], max_retries=3, timeout=45)
            files = []
            for root, _, fnames in os.walk(output_dir):
                for f in fnames:
                    if f.lower().endswith(('.jpg', '.jpeg', '.png', '.webp')): files.append(os.path.join(root, f))
            if not files: raise DownloadError("No images found")
        else:
            with YoutubeDL({'format': 'best', 'outtmpl': os.path.join(output_dir, '%(title)s_%(autonumber)s.%(ext)s'), 'quiet': True}) as ydl:
                ydl.extract_info(url, download=True)
                files = [os.path.join(output_dir, f) for f in os.listdir(output_dir) if f.lower().endswith(('.jpg', '.jpeg', '.png', '.webp'))]
            if not files: raise DownloadError("No images found")
        
        if len(files) == 1:
            dest = os.path.join(UPLOAD_FOLDER, os.path.basename(files[0]))
            os.replace(files[0], dest)
            import shutil
            shutil.rmtree(output_dir, ignore_errors=True)
            schedule_deletion(dest)
            return dest, 'single'
        
        zip_path = os.path.join(UPLOAD_FOLDER, f'tiktok_images_{unique_id}.zip')
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for f in files: zipf.write(f, os.path.basename(f))
        import shutil
        shutil.rmtree(output_dir, ignore_errors=True)
        schedule_deletion(zip_path)
        return zip_path, 'multiple'
    except Exception as e:
        import shutil
        if os.path.exists(output_dir): shutil.rmtree(output_dir, ignore_errors=True)
        raise e

@lru_cache(maxsize=100)
def fetch_video_info(url):
    # Performance hack: Run both yt-dlp and gallery-dl logic concurrently for /photo/ links
    def fetch_gallery_dl():
        if '/photo/' in url:
            # Apply throttling for photo requests
            throttle_photo_request(url, min_delay=2.0)
            try:
                cmd = ["python", "-m", "gallery_dl", "--dump-json", "-q", url]
                res = run_gallery_dl_with_retry(cmd, max_retries=3, timeout=30)
                data = json.loads(res.stdout) if res.stdout.strip().startswith('{') or res.stdout.strip().startswith('[') else [json.loads(l) for l in res.stdout.strip().split('\n') if l.strip()]
                entry = None
                def find_e(d):
                    if isinstance(d, dict):
                        if 'title' in d or 'imagePost' in d: return d
                        for v in d.values():
                            f = find_e(v)
                            if f: return f
                    if isinstance(d, list):
                        for i in d:
                            f = find_e(i)
                            if f: return f
                    return None
                entry = find_e(data)
                if entry:
                    images = []
                    if 'imagePost' in entry and 'images' in entry['imagePost']:
                        for img in entry['imagePost']['images']:
                            if 'imageURL' in img and 'urlList' in img['imageURL']: images.append(img['imageURL']['urlList'][0])
                    elif 'files' in entry:
                        images = [f for f in entry['files'] if isinstance(f, str) and f.startswith('http')]
                    
                    author_obj = entry.get('author')
                    author_name = "Unknown"
                    if isinstance(author_obj, dict):
                        author_name = author_obj.get('nickname') or author_obj.get('uniqueId') or "Unknown"
                    elif isinstance(author_obj, str):
                        author_name = author_obj
                    
                    return {
                        'title': entry.get('title') or entry.get('description') or "TikTok Photo",
                        'author': author_name,
                        'thumbnail': images[0] if images else "",
                        'duration': 0,
                        'views': 0, 'likes': 0,
                        'webpage_url': url,
                        'is_image_post': True,
                        'image_count': len(images),
                        'post_type': 'image',
                        'images': images
                    }
            except Exception as e:
                logger.debug(f"Gallery-dl check failed (expected for non-slideshows): {e}")
        return None

    def fetch_ytdlp():
        with YoutubeDL({'quiet': True, 'skip_download': True, 'noplaylist': True, 'no_warnings': True}) as ydl:
            try:
                info = ydl.extract_info(url, download=False)
                is_img = True if ('entries' in info and info['entries']) or info.get('ext') in ['jpg', 'jpeg', 'png', 'webp'] or info.get('duration') is None else False
                return {
                    'title': info.get('title'),
                    'author': info.get('uploader'),
                    'thumbnail': info.get('thumbnail'),
                    'duration': info.get('duration'),
                    'views': info.get('view_count'),
                    'likes': info.get('like_count'),
                    'webpage_url': info.get('webpage_url'),
                    'is_image_post': is_img,
                    'image_count': len(info.get('entries', [])) if is_img else 0,
                    'post_type': 'image' if is_img else 'video'
                }
            except Exception as e:
                return {"error": str(e)}

    # If it's a photo URL, run both in parallel to see which returns first or better data
    if '/photo/' in url:
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
            future_gallery = executor.submit(fetch_gallery_dl)
            future_ytdlp = executor.submit(fetch_ytdlp)
            
            gallery_res = future_gallery.result()
            if gallery_res: return gallery_res
            return future_ytdlp.result()
    
    return fetch_ytdlp()
