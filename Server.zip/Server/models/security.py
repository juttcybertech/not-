import os, sqlite3, requests, logging
from datetime import datetime
from functools import wraps
from flask import request, jsonify

# Setup basic logging for the model
logger = logging.getLogger(__name__)

# Constants
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, 'logs.db')
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'downloads')

# Ensure directories exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def init_db():
    """Initializes the SQLite database with the logs and ip_blacklist tables."""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS logs
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                 timestamp TEXT, ip TEXT, action TEXT, url TEXT, user_agent TEXT,
                 country TEXT, city TEXT, isp TEXT, continent TEXT, timezone TEXT)''')
    c.execute("CREATE INDEX IF NOT EXISTS idx_logs_action ON logs (action);")
    c.execute("CREATE INDEX IF NOT EXISTS idx_logs_timestamp ON logs (timestamp);")
    c.execute("CREATE INDEX IF NOT EXISTS idx_logs_ip ON logs (ip);")
    
    c.execute('''CREATE TABLE IF NOT EXISTS ip_blacklist
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  ip TEXT UNIQUE, reason TEXT, timestamp TEXT)''')
    conn.commit()
    conn.close()

def is_ip_blacklisted(ip):
    """Checks if an IP address is in the blacklist."""
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT 1 FROM ip_blacklist WHERE ip = ?", (ip,))
        result = c.fetchone()
        conn.close()
        return result is not None
    except Exception as e:
        logger.error(f"Error checking blacklist for {ip}: {e}")
        return False

def get_ip_info(ip):
    """Fetches geolocation and ISP information for an IP address using ip-api.com."""
    try:
        # Note: In production, consider a local MaxMind database for better performance
        res = requests.get(f"http://ip-api.com/json/{ip}", timeout=5)
        return res.json() if res.status_code == 200 else {}
    except Exception as e:
        logger.error(f"Error fetching IP info for {ip}: {e}")
        return {}

def log_user(ip, url, action, user_agent):
    """Logs user activity to the database, including geolocation data."""
    ip_info = get_ip_info(ip)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("PRAGMA journal_mode=WAL;")
        c.execute('''INSERT INTO logs 
                     (timestamp, ip, action, url, user_agent, country, city, isp, continent, timezone)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                     (timestamp, ip, action, url, user_agent,
                      ip_info.get('country'), ip_info.get('city'), ip_info.get('isp'),
                      ip_info.get('continent'), ip_info.get('timezone')))
        conn.commit()
        conn.close()
    except Exception as e:
        logger.error(f"Error logging user activity for {ip}: {e}")

def require_api_secret(api_access_secret):
    """Decorator to require a valid API secret in headers or JSON payload."""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            client_secret = request.headers.get('X-API-Secret')
            if not client_secret:
                try:
                    data = request.get_json(silent=True)
                    if data:
                        client_secret = data.get('api_secret')
                except:
                    pass
            if api_access_secret and client_secret == api_access_secret:
                return f(*args, **kwargs)
            return jsonify({"error": "Unauthorized"}), 403
        return decorated_function
    return decorator
