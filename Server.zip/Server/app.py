import os, subprocess, time, uuid, requests, sqlite3, zipfile, json, logging, traceback
from threading import Semaphore, Thread
from flask import Flask, request, jsonify, send_file, render_template, g, send_from_directory, url_for
from flask_cors import CORS
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from collections import Counter
from functools import wraps
from datetime import datetime
from dotenv import load_dotenv

# ✅ Import from Models
from models.downloader import (
    download_tiktok_video, 
    download_audio, 
    download_tiktok_images, 
    fetch_video_info, 
    resolve_tiktok_url, 
    schedule_deletion,
    start_cleanup_service
)
from models.security import (
    init_db,
    is_ip_blacklisted,
    log_user,
    require_api_secret,
    DB_PATH,
    UPLOAD_FOLDER
)

# ✅ Initialize Flask app
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIR = os.path.abspath(os.path.join(BASE_DIR, "..", "front end"))

app = Flask(__name__)

# ✅ Rate Limiting for security
limiter = Limiter(
    get_remote_address,
    app=app,
    default_limits=["10000 per day", "2000 per hour"],
    storage_uri="memory://"
)

# ✅ Load environment variables
load_dotenv(os.path.join(BASE_DIR, "api.env"))

# ✅ Enhanced Logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(BASE_DIR, "critical_crash.log")),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

@app.errorhandler(Exception)
def handle_exception(e):
    err = traceback.format_exc()
    logger.error(f"GLOBAL EXCEPTION CAUGHT:\n{err}")
    return f"<h1>Global Error Caught</h1><pre>{err}</pre>", 500

@app.before_request
def debug_logger():
    ip = request.headers.get("X-Forwarded-For", request.remote_addr)
    blacklisted = is_ip_blacklisted(ip)
    
    if blacklisted:
        return jsonify({"error": "Your IP has been blacklisted due to suspicious activity."}), 403
        
    # print(f"DEBUG: {request.method} request to {request.path} from {ip}")

# ✅ CORS
CORS(app)

ADMIN_USERNAME = os.getenv("ADMIN_USERNAME")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD")
API_ACCESS_SECRET = os.getenv("API_ACCESS_SECRET")
API_KEY = os.getenv("API_KEY")
ADMIN_ACCESS_PATH = os.getenv("ADMIN_ACCESS_PATH", "/admin")

# ✅ Initialize DB on Startup
init_db()
start_cleanup_service()

# All DB and IP helpers moved to models/security.py

# def schedule_deletion(file_path, delay=600):
#     def delete_file():
#         time.sleep(delay)
#         if os.path.exists(file_path):
#             os.remove(file_path)
#     Thread(target=delete_file, daemon=True).start()

# ✅ API Routes
@app.route('/api/ping', methods=['GET', 'POST'])
def api_ping():
    return jsonify({ "status": "connected" })

@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({ "status": "ok" })

# def resolve_tiktok_url(url):
#     if not url: return url
#     if 'vt.tiktok.com' in url or 'vm.tiktok.com' in url:
#         try:
#             headers = {'User-Agent': 'Mozilla/5.0'}
#             resp = requests.head(url, headers=headers, allow_redirects=True, timeout=10)
#             return resp.url
#         except:
#             return url
#     return url

user_semaphore = Semaphore(300)

@app.route('/api/preview', methods=['POST'])
@require_api_secret(os.getenv("API_ACCESS_SECRET"))
def api_preview():
    if not user_semaphore.acquire(blocking=False):
        return jsonify({"error": "Server busy"}), 503
    try:
        data = request.get_json()
        url = resolve_tiktok_url(data.get('url'))
        if not url or 'tiktok.com' not in url:
            return jsonify({"error": "Invalid URL"}), 400
        ip = request.headers.get("X-Forwarded-For", request.remote_addr)
        log_user(ip, url, "preview", request.headers.get('User-Agent'))
        info = fetch_video_info(url)
        return jsonify(info) if "error" not in info else (jsonify(info), 400)
    finally:
        user_semaphore.release()

@app.route('/api/download/video', methods=['POST'])
@require_api_secret(os.getenv("API_ACCESS_SECRET"))
def api_download_video():
    if not user_semaphore.acquire(blocking=False):
        return jsonify({"error": "Server busy"}), 503
    try:
        data = request.get_json()
        url = resolve_tiktok_url(data.get('url'))
        ip = request.headers.get("X-Forwarded-For", request.remote_addr)
        log_user(ip, url, "download_video", request.headers.get('User-Agent'))
        try:
            file_path = download_tiktok_video(url)
            return send_file(file_path, as_attachment=True)
        except DownloadError as e:
            return jsonify({"error": str(e)}), 500
    finally:
        user_semaphore.release()

@app.route('/api/download/images', methods=['POST'])
@require_api_secret(os.getenv("API_ACCESS_SECRET"))
def api_download_images():
    if not user_semaphore.acquire(blocking=False):
        return jsonify({"error": "Server busy"}), 503
    try:
        data = request.get_json()
        url = resolve_tiktok_url(data.get('url'))
        ip = request.headers.get("X-Forwarded-For", request.remote_addr)
        log_user(ip, url, "download_images", request.headers.get('User-Agent'))
        image_url = data.get('image_url')
        try:
            if image_url:
                if 'tiktokcdn' not in image_url and 'tiktok' not in image_url:
                     return jsonify({"error": "Invalid Image URL"}), 400
                unique_id = str(uuid.uuid4())[:8]
                temp_path = os.path.join(UPLOAD_FOLDER, f"image_{unique_id}.jpg")
                r = requests.get(image_url, stream=True)
                if r.status_code == 200:
                    with open(temp_path, 'wb') as f:
                        for chunk in r.iter_content(chunk_size=8192):
                            f.write(chunk)
                    schedule_deletion(temp_path)
                    return send_file(temp_path, as_attachment=True, download_name=f"tiktok_image_{unique_id}.jpg")
                return jsonify({"error": "Failed to download image"}), 500
            file_path, type = download_tiktok_images(url)
            return send_file(file_path, as_attachment=True)
        except DownloadError as e:
            return jsonify({"error": str(e)}), 500
    except Exception as e:
         return jsonify({"error": str(e)}), 500
    finally:
        user_semaphore.release()

@app.route('/api/download/audio', methods=['POST'])
@require_api_secret(os.getenv("API_ACCESS_SECRET"))
def api_download_audio():
    if not user_semaphore.acquire(blocking=False):
        return jsonify({"error": "Server busy"}), 503
    try:
        data = request.get_json()
        url = resolve_tiktok_url(data.get('url'))
        ip = request.headers.get("X-Forwarded-For", request.remote_addr)
        log_user(ip, url, "download_audio", request.headers.get('User-Agent'))
        try:
            file_path = download_audio(url)
            return send_file(file_path, as_attachment=True)
        except DownloadError as e:
            return jsonify({"error": str(e)}), 500
    finally:
        user_semaphore.release()

# ✅ Admin Routes
@app.route(ADMIN_ACCESS_PATH + "/ip-management", methods=['GET', 'POST'], endpoint='ip_management')
def ip_management():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            conn = sqlite3.connect(DB_PATH)
            conn.row_factory = sqlite3.Row
            c = conn.cursor()
            action = request.form.get("admin_action")
            if action == "block_ip":
                ip_to_block = request.form.get("ip")
                if ip_to_block:
                    c.execute("INSERT OR IGNORE INTO ip_blacklist (ip, reason, timestamp) VALUES (?, ?, ?)",
                              (ip_to_block, request.form.get("reason", "Manual block"), datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
                    conn.commit()
            elif action == "unblock_ip":
                ip_to_unblock = request.form.get("ip")
                if ip_to_unblock:
                    c.execute("DELETE FROM ip_blacklist WHERE ip = ?", (ip_to_unblock,))
                    conn.commit()
            c.execute("SELECT * FROM ip_blacklist ORDER BY timestamp DESC")
            blacklist = c.fetchall()
            conn.close()
            return render_template('ip_management.html', blacklist=blacklist, username=username, password=password, ADMIN_ACCESS_PATH=ADMIN_ACCESS_PATH)
    return jsonify({"error": "Unauthorized"}), 403

@app.route(ADMIN_ACCESS_PATH + "/ip-details/<ip>", methods=['POST'], endpoint='ip_details')
def get_ip_details(ip):
    username = request.form.get("username")
    password = request.form.get("password")
    if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("SELECT country, city, isp, continent, timezone, user_agent FROM logs WHERE ip = ? ORDER BY id DESC LIMIT 1", (ip,))
        details = c.fetchone()
        conn.close()
        return jsonify(dict(details)) if details else (jsonify({"error": "Not found"}), 404)
    return jsonify({"error": "Unauthorized"}), 403

@app.route(ADMIN_ACCESS_PATH + "/raw-logs", methods=['POST'], endpoint='raw_logs')
def raw_logs():
    username = request.form.get("username")
    password = request.form.get("password")
    if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
        page = request.form.get('page', 1, type=int)
        LOGS_PER_PAGE = 50
        offset = (page - 1) * LOGS_PER_PAGE
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("SELECT COUNT(id) FROM logs")
        total_logs = c.fetchone()[0]
        total_pages = (total_logs + LOGS_PER_PAGE - 1) // LOGS_PER_PAGE
        c.execute("SELECT * FROM logs ORDER BY id DESC LIMIT ? OFFSET ?", (LOGS_PER_PAGE, offset))
        logs = c.fetchall()
        conn.close()
        return render_template('raw_logs.html', logs=logs, current_page=page, total_pages=total_pages, username=username, password=password)
    return jsonify({"error": "Unauthorized"}), 403

@app.route(ADMIN_ACCESS_PATH, methods=['GET', 'POST'], endpoint='admin')
def admin():
    error = None
    try:
        if request.method == "POST":
            username = request.form.get("username")
            password = request.form.get("password")
            if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
                conn = sqlite3.connect(DB_PATH)
                conn.row_factory = sqlite3.Row
                conn.execute("PRAGMA journal_mode=WAL;")
                c = conn.cursor()
                
                c.execute("SELECT COUNT(*), COUNT(DISTINCT ip) FROM logs")
                total_requests, unique_visitors = c.fetchone()
                
                c.execute("SELECT action, COUNT(*) FROM logs GROUP BY action")
                action_counts = c.fetchall()
                action_labels = [row['action'].replace('_', ' ').capitalize() for row in action_counts]
                action_data = [row[1] for row in action_counts]
                
                c.execute("SELECT country, COUNT(*) as count FROM logs WHERE country IS NOT NULL GROUP BY country ORDER BY count DESC LIMIT 5")
                country_counts = c.fetchall()
                country_labels = [row['country'] for row in country_counts]
                country_data = [row['count'] for row in country_counts]
                
                c.execute("SELECT city, COUNT(*) as count FROM logs WHERE city IS NOT NULL GROUP BY city ORDER BY count DESC LIMIT 5")
                city_counts = c.fetchall()
                city_labels = [row['city'] for row in city_counts]
                city_data = [row['count'] for row in city_counts]
                
                c.execute("SELECT date(timestamp) as day, COUNT(*) as count FROM logs WHERE date(timestamp) >= date('now', '-15 days') GROUP BY day ORDER BY day ASC")
                daily_requests = c.fetchall()
                time_labels = [row['day'] for row in daily_requests]
                time_data = [row['count'] for row in daily_requests]
                
                c.execute("SELECT user_agent, COUNT(*) as count FROM logs WHERE user_agent IS NOT NULL GROUP BY user_agent ORDER BY count DESC LIMIT 5")
                user_agent_counts = c.fetchall()
                user_agent_labels = [ (agent[:40] + '...') if len(agent) > 40 else agent for agent in [row['user_agent'] for row in user_agent_counts] ]
                user_agent_data = [row['count'] for row in user_agent_counts]
                
                c.execute("SELECT url, COUNT(*) as count FROM logs WHERE url IS NOT NULL AND (action = 'download_video' OR action = 'download_audio') GROUP BY url ORDER BY count DESC LIMIT 5")
                url_counts = c.fetchall()
                url_labels = [row['url'] for row in url_counts]
                url_data = [row['count'] for row in url_counts]

                c.execute("SELECT strftime('%H', timestamp) as hour, COUNT(*) as count FROM logs GROUP BY hour ORDER BY hour ASC")
                hourly_counts_raw = c.fetchall()
                hourly_dict = {row['hour']: row['count'] for row in hourly_counts_raw}
                hourly_labels = [f"{h:02d}:00" for h in range(24)]
                hourly_data = [hourly_dict.get(f"{h:02d}", 0) for h in range(24)]
                
                analytics = {
                    'total_requests': total_requests or 0,
                    'unique_visitors': unique_visitors or 0,
                    'charts': {
                        'actions': {'labels': action_labels, 'data': action_data},
                        'countries': {'labels': country_labels, 'data': country_data},
                        'cities': {'labels': city_labels, 'data': city_data},
                        'timeline': {'labels': time_labels, 'data': time_data},
                        'user_agents': {'labels': user_agent_labels, 'data': user_agent_data},
                        'top_urls': {'labels': url_labels, 'data': url_data},
                        'by_hour': {'labels': hourly_labels, 'data': hourly_data}
                    }
                }
                conn.close()
                return render_template('admin.html', analytics=analytics, username=username, password=password, ADMIN_ACCESS_PATH=ADMIN_ACCESS_PATH)
            else:
                error = "Invalid username or password."
    except Exception as e:
        return f"<h1>Internal Server Error</h1><pre>{traceback.format_exc()}</pre>", 500
    return render_template('login.html', error=error)

@app.errorhandler(429)
def ratelimit_handler(e):
    return jsonify(error=f"ratelimit exceeded: {e.description}"), 429

# ✅ Server Entry Point

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=False)