import requests
import threading
import time
import os
from dotenv import load_dotenv

# Load config from api.env
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE_DIR, "api.env"))

TARGET = "http://127.0.0.1:8080"
SECRET = os.getenv("API_ACCESS_SECRET")
CONCURRENCY = 300  # Number of concurrent threads to test

results = {
    "success": 0,
    "failure": 0,
    "busy": 0,
    "latencies": []
}

lock = threading.Lock()

def send_request(id):
    start_time = time.time()
    try:
        # Test the lightweight ping endpoint to verify raw connection handling
        res = requests.get(
            f"{TARGET}/api/ping",
            timeout=10
        )
        latency = time.time() - start_time
        
        with lock:
            results["latencies"].append(latency)
            if res.status_code == 400 or res.status_code == 200:
                results["success"] += 1
            elif res.status_code == 503:
                results["busy"] += 1
            else:
                results["failure"] += 1
                
    except Exception as e:
        with lock:
            results["failure"] += 1

def run_test():
    print(f"Starting Load Test: {CONCURRENCY} concurrent requests to {TARGET}...")
    
    # 1. Initial Health Check
    health = requests.get(f"{TARGET}/api/health").json()
    print(f"Initial Server Health: {health}")
    
    threads = []
    for i in range(CONCURRENCY):
        t = threading.Thread(target=send_request, args=(i,))
        threads.append(t)
        
    start_test = time.time()
    for t in threads:
        t.start()
        
    # Monitor health in a separate thread while requests are flying
    def monitor():
        for _ in range(5):
            try:
                h = requests.get(f"{TARGET}/api/health", timeout=1).json()
                print(f"   [Monitor] Available Threads: {h.get('users_available')}")
            except:
                pass
            time.sleep(0.5)
            
    m_thread = threading.Thread(target=monitor)
    m_thread.start()

    for t in threads:
        t.join()
    
    end_test = time.time()
    
    avg_latency = sum(results["latencies"]) / len(results["latencies"]) if results["latencies"] else 0
    
    print("\n--- Test Results ---")
    print(f"Total Requests: {CONCURRENCY}")
    print(f"Success: {results['success']}")
    print(f"Server Busy (503): {results['busy']}")
    print(f"Failed: {results['failure']}")
    print(f"Average Latency: {avg_latency:.2f}s")
    print(f"Total Test Time: {end_test - start_test:.2f}s")
    print("--------------------")

    if results["success"] + results["busy"] >= CONCURRENCY * 0.9:
        print("VERIFIED: Server handled the concurrency load without crashing.")
    else:
        print("WARNING: Server dropped significant requests or crashed.")

if __name__ == "__main__":
    run_test()
